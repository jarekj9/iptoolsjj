from setuptools import setup

setup(name='iptoolsjj',
      version='1.0.3',
      description='IP Tools',
      url='https://github.com/jarekj9/iptoolsjj',
      author='Jaroslaw Jankun',
      author_email='jaroslaw.jankun@gmail.com',
      license='MIT',
      packages=['iptoolsjj'],
      zip_safe=False)
